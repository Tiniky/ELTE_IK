# Task 2: You've just won a phone!

- [x] a.
- [x] b.
- [x] c.
- [x] d.
- [x] e.
- [x] f.
- [x] g.
- [x] h.
