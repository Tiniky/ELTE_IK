# Task 3: Gift list

- [x] a.
- [x] b.
- [x] c.
- [] d.
- [ ] e.
- [ ] f.
- [ ] g.
- [ ] h.