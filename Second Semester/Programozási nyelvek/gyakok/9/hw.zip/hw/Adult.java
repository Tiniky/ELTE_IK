package hw;

public class Adult extends Guest {
    public Adult(String name, int age){
        super(name, age);
    }
}
