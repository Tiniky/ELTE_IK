package hw;

public class Minor extends Guest{
    public Minor(String name, int age){
        super(name, age);
    }
}
