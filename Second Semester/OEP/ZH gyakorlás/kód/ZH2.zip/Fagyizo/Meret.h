//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_MERET_H
#define FAGYIZO_MERET_H

#include <string>

class Meret {
public:
    int suly;

    static Meret* Alakit(const std::string& s);

protected:
    explicit Meret(int s) : suly(s) { }
    ~Meret() = default;

};

class Kicsi : public Meret {
private:
    static Kicsi* storage;

    explicit Kicsi() : Meret(55) { }

public:
    static Kicsi* instance() {
        if(storage == nullptr) {
            storage = new Kicsi;
        }

        return storage;
    }

    static void destroy() {
        delete storage;
        storage = nullptr;
    }
};

class Kozepes : public Meret {
private:
    static Kozepes* storage;

    explicit Kozepes() : Meret(70) { }

public:
    static Kozepes* instance() {
        if(storage == nullptr) {
            storage = new Kozepes;
        }

        return storage;
    }

    static void destroy() {
        delete storage;
        storage = nullptr;
    }
};

class Nagy : public Meret {
private:
    static Nagy* storage;

    explicit Nagy() : Meret(90) { }

public:
    static Nagy* instance() {
        if(storage == nullptr) {
            storage = new Nagy;
        }

        return storage;
    }

    static void destroy() {
        delete storage;
        storage = nullptr;
    }
};

#endif //FAGYIZO_MERET_H
