//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_KEHELY_H
#define FAGYIZO_KEHELY_H

#include <vector>

#include "Gomboc.h"
#include "Meret.h"

class Kehely {
private:
    std::vector<Gomboc*> gombocok;

public:
    Meret* meret;

    Kehely(Meret* m, std::vector<Iz> izek);
    ~Kehely() = default;

    int Suly();
    bool Epres();
};


#endif //FAGYIZO_KEHELY_H
