//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_IZ_H
#define FAGYIZO_IZ_H

enum Iz {
    eper, csoki, vanilia, szilva
};

#endif //FAGYIZO_IZ_H
