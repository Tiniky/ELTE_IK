//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#include "Fagyizo.h"

void Fagyizo::Felvesz(std::vector<Kivansag> list, std::string& time) {
    Rendeles* r = new Rendeles(time);

    for(auto& e : list) {
        Meret* m = Meret::Alakit(e.m);
        r->Hozzavesz(new Kehely(m, e.i));
    }

    napi.push_back(r);
}

int Fagyizo::Hany(Meret* t) {
    int s = 0;

    for(auto* e : napi) {
        s += e->Darab(t);
    }

    return s;
}

int Fagyizo::Bevetel() {
    int s = 0;

    for(auto* e : napi) {
        s += e->Ar();
    }

    return s;
}
