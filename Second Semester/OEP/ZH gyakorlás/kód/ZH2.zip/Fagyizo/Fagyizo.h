//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_FAGYIZO_H
#define FAGYIZO_FAGYIZO_H

#include <string>
#include <vector>

#include "Rendeles.h"

struct Kivansag {
    std::string m;
    std::vector<Iz> i;
};

class Fagyizo {
private:
    std::vector<Rendeles*> napi;

public:
    std::string nev;
    std::string cim;

    int ar;

    Fagyizo(std::string& n, std::string& c, int a) : nev(n), cim(c), ar(a) { }
    ~Fagyizo() = default;

    void Felvesz(std::vector<Kivansag> list, std::string& time);
    int Hany(Meret* t);
    int Bevetel();
};


#endif //FAGYIZO_FAGYIZO_H
