//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_CUKRASZDA_H
#define FAGYIZO_CUKRASZDA_H

#include <vector>

#include "Fagyizo.h"

class Cukraszda {
private:
    std::vector<Fagyizo*> uzletek;

public:
    explicit Cukraszda(std::vector<Fagyizo*>& u) : uzletek(u) { }
    ~Cukraszda() = default;
};


#endif //FAGYIZO_CUKRASZDA_H
