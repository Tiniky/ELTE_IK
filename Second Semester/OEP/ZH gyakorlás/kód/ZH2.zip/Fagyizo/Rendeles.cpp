//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#include "Rendeles.h"

void Rendeles::Hozzavesz(Kehely* k) {
    kelyhek.push_back(k);
}

int Rendeles::Ar() {
    int s = 0;

    for(auto* e : kelyhek) {
        s += e->Suly();
    }

    return s;
}

int Rendeles::Darab(Meret* m) {
    int s = 0;

    for(auto* e : kelyhek) {
        if(e->Epres() && e->meret == m) {
            s++;
        }
    }

    return s;
}
