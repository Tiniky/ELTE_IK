//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#include "Kehely.h"

int Kehely::Suly() {
    return gombocok.size() * meret->suly;
}

bool Kehely::Epres() {
    bool volt = false;

    for(auto* e : gombocok) {
        if(e->iz == Iz::eper) {
            volt = true;
        }
    }

    return volt;
}

Kehely::Kehely(Meret* m, std::vector<Iz> izek) {
    this->meret = m;

    if(3 <= izek.size() && izek.size() <= 5) {
        for(auto& i : izek) {
            gombocok.push_back(new Gomboc(i));
        }
    }
}
