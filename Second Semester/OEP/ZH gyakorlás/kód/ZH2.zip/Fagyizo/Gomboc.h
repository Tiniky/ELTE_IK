//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_GOMBOC_H
#define FAGYIZO_GOMBOC_H

#include "Iz.h"

class Gomboc {
public:
    Iz iz;

    explicit Gomboc(Iz& iz) : iz(iz) { }
    ~Gomboc() = default;
};


#endif //FAGYIZO_GOMBOC_H
