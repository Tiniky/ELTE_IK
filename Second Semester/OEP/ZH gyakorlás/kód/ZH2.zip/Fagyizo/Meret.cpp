//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#include "Meret.h"

Kicsi* Kicsi::storage = nullptr;
Kozepes* Kozepes::storage = nullptr;
Nagy* Nagy::storage = nullptr;

Meret* Meret::Alakit(const std::string& s) {
    if(s == "kicsi") {
        return Kicsi::instance();
    } else if(s == "kozepes") {
        return Kozepes::instance();
    } else {
        return Nagy::instance();
    }
}
