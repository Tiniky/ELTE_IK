//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#include <iostream>
#include <fstream>
#include <vector>

#include "Cukraszda.h"
#include "Fagyizo.h"

int main() {
    std::ifstream is("input.txt");
    if(!is.good()) {
        return 1;
    }

    int n = 0;
    is >> n;

    std::vector<Fagyizo*> uzletek;
    for(int i = 0; i < n; i++) {
        std::string nev;
        int ar;
        std::string cim;

        is >> nev >> ar;
        std::getline(is, cim);

        uzletek.push_back(new Fagyizo(nev, cim, ar));
    }

    Cukraszda* cukraszda = new Cukraszda(uzletek);

    std::string uzlet;
    std::string ido;
    std::string meret;
    int izekSzama = 0;

    while(is >> uzlet >> ido >> meret >> izekSzama) {
        std::vector<Iz> izek;

        for(int i = 0; i < izekSzama; i++) {
            std::string s;
            is >> s;

            if(s == "eper") {
                izek.push_back(Iz::eper);
            } else if(s == "csoki") {
                izek.push_back(Iz::csoki);
            } else if(s == "vanilia") {
                izek.push_back(Iz::vanilia);
            } else {
                izek.push_back(Iz::szilva);
            }
        }

        Fagyizo* fagyizo = nullptr;
        for(auto* e : uzletek) {
            if(e->nev == uzlet) {
                fagyizo = e;
                break;
            }
        }

        fagyizo->Felvesz({ { meret, izek } }, ido);
    }

    std::cout << uzletek[0]->Hany(Kozepes::instance()) << std::endl;
    std::cout << uzletek[0]->Bevetel() << std::endl;

    return 0;
}