//
// Created by Gerber Lóránt Viktor on 08/06/2022.
//

#ifndef FAGYIZO_RENDELES_H
#define FAGYIZO_RENDELES_H

#include <vector>
#include <string>

#include "Kehely.h"

class Rendeles {
private:
    std::vector<Kehely*> kelyhek;

public:
    std::string idopont;

    explicit Rendeles(std::string& time) : idopont(time) { }
    ~Rendeles() = default;

    void Hozzavesz(Kehely*);
    int Ar();
    int Darab(Meret* m);
};


#endif //FAGYIZO_RENDELES_H
