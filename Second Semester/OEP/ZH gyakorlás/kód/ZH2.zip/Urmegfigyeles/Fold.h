#ifndef FOLD_H
#define FOLD_H

#include <tuple>
#include <vector>
#include "Allomas.h"

class Fold {
    private:
        static Fold* storage;

    public:
        std::vector<Allomas*> allomasok;

        void Uzembe(Allomas* a);
        int Szamlal(double c1, double c2) const;
        std::tuple<bool, Allomas*> Legnagyobb() const;

        static Fold* instance() {
            if(storage == nullptr) {
                storage = new Fold;
            }

            return storage;
        }

        static void destroy() {
            delete storage;
            storage = nullptr;
        }
};

#endif