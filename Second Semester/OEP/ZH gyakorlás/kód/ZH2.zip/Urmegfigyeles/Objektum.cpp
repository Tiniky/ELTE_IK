#include "Objektum.h"

double Aszteroida::TomegSzorzo() const {
    return 1000000;
}

double Aszteroida::TavSzorzo() const {
    return 1000;
}

bool Aszteroida::IsAszteroida() const {
    return true;
}

double Nap::TomegSzorzo() const {
    return 1.98e30;
}

double Nap::TavSzorzo() const {
    return 9.5e12;
}

double Feketelyuk::TomegSzorzo() const {
    return 1.98e30;
}

double Feketelyuk::TavSzorzo() const {
    return 9.5e20;
}