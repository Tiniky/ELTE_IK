#include "Allomas.h"

void Allomas::Eszlel(Objektum* o, std::string d, double to, double ta) {
    megf.push_back(new Megfigyeles(o, d, to, ta));
}

bool Allomas::Veszely(double c1, double c2) const {
    bool volt = false;

    for(Megfigyeles* e : megf) {
        if(AtlTom(e->obj) > c1 && AtlTav(e->obj) < c2) {
            volt = true;
        }
    }

    return volt;
}

std::tuple<bool, double> Allomas::Max() const {
    bool l = false;
    double max = 0.;

    for(Megfigyeles* e : megf) {
        if(e->obj->IsAszteroida() && e->Tomeg() > max) {
            max = e->Tomeg();
            l = true;
        }
    }

    return { l, max };
}

double Allomas::AtlTom(Objektum* o) const {
    double s = 0.;
    double c = 0.;

    for(Megfigyeles* e : megf) {
        if(e->obj == o) {
            s += e->Tomeg();
            c++;
        }
    }

    return s / c;
}

double Allomas::AtlTav(Objektum* o) const {
    double s = 0.;
    double c = 0.;

    for(Megfigyeles* e : megf) {
        if(e->obj == o) {
            s += e->Tav();
            c++;
        }
    }

    return s / c;
}