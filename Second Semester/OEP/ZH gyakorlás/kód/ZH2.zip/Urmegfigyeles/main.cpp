#include <iostream>
#include <fstream>
#include <sstream>

#include "Fold.h"
#include "Megfigyeles.h"
#include "Allomas.h"
#include "Objektum.h"

int main() {
    std::ifstream is("input.txt");
    if(!is.good()) {
        return 1;
    }

    Fold* fold = Fold::instance();

    int allomasokSzama = 0;
    is >> allomasokSzama;

    for(int i = 0; i < allomasokSzama; i++) {
        std::string azon;
        is >> azon;

        fold->Uzembe(new Allomas(azon));
    }

    int objektumokSzama = 0;
    is >> objektumokSzama;

    for(int i = 0; i < objektumokSzama; i++) {
        std::string azon;
        char tipus;
        std::string line;

        is >> azon >> std::ws >> tipus;
        std::getline(is, line);
        std::stringstream ss(line);

        Objektum* obj = nullptr;

        switch (tipus) {
            case 'a':
                obj = new Aszteroida(azon);
                break;

            case 'n':
                obj = new Nap(azon);
                break;

            case 'f':
                obj = new Feketelyuk(azon);
                break;

            default:
                break;
        }

        int allomasIndex;
        while(ss >> allomasIndex) {
            std::string datum;
            double tomeg;
            double tav;

            ss >> datum >> tomeg >> tav;

            fold->allomasok[allomasIndex]->Eszlel(obj, datum, tomeg, tav);
        }
    }

    double c1;
    double c2;

    is >> c1 >> c2;

    // a
    int veszelyesSzama = 0;
    for(Allomas* e : fold->allomasok) {
        if(e->Veszely(c1, c2)) {
            veszelyesSzama++;
        }
    }

    // b
    std::string azon = "nem talaltunk";
    std::tuple<bool, Allomas*> max = fold->Legnagyobb();
    if(std::get<0>(max)) {
        azon = std::get<1>(max)->azon;
    }

    std::cout << veszelyesSzama << " " << azon << std::endl;

    Fold::destroy();

    return 0;
}