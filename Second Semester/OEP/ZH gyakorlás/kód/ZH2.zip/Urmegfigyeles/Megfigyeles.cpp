#include "Megfigyeles.h"

double Megfigyeles::Tomeg() const {
    return tomeg * obj->TomegSzorzo();
}

double Megfigyeles::Tav() const {
    return tav * obj->TavSzorzo();
}