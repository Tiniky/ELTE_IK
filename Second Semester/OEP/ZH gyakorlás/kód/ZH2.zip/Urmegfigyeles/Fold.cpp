#include "Fold.h"

Fold* Fold::storage = nullptr;

void Fold::Uzembe(Allomas* a) {
    allomasok.push_back(a);
}

int Fold::Szamlal(double c1, double c2) const {
    int s = 0;

    for(Allomas* e : allomasok) {
        if(e->Veszely(c1, c2)) {
            s++;
        }
    }

    return s;
}

std::tuple<bool, Allomas*> Fold::Legnagyobb() const {
    bool l = false;
    double max = 0.;
    Allomas* all = nullptr;

    for(Allomas* e : allomasok) {
        std::tuple<bool, double> emax = e->Max();

        bool first = std::get<0>(emax);
        double second = std::get<1>(emax);

        if(first && second > max) {
            l = true;
            max = second;
            all = e;
        }
    }

    return { l, all };
}