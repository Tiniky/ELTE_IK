#ifndef ALLOMAS_H
#define ALLOMAS_H

#include <string>
#include <vector>
#include <tuple>

#include "Megfigyeles.h"

class Allomas {
    public:
        std::vector<Megfigyeles*> megf;
        std::string azon;

        Allomas(std::string a) : azon(a) { }
        ~Allomas() = default;

        void Eszlel(Objektum* o, std::string d, double to, double ta);
        bool Veszely(double c1, double c2) const;
        std::tuple<bool, double> Max() const;

    private:
        double AtlTom(Objektum* o) const;
        double AtlTav(Objektum* o) const;
};

#endif