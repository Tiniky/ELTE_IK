#ifndef OBJEKTUM_H
#define OBJEKTUM_H

#include <string>

class Objektum {
    public:
        std::string azon;

    protected:
        Objektum(std::string a) : azon(a) { }

    public:
        ~Objektum() = default;

        virtual double TomegSzorzo() const = 0;
        virtual double TavSzorzo() const = 0;
        virtual bool IsAszteroida() const {
            return false;
        }

        std::string get_azon() { return azon; }
};

class Aszteroida : public Objektum {
    public:
        Aszteroida(std::string a) : Objektum(a) { }

        double TomegSzorzo() const override;
        double TavSzorzo() const override;
        bool IsAszteroida() const override;
};

class Nap : public Objektum {
    public:
        Nap(std::string a) : Objektum(a) { }

        double TomegSzorzo() const override;
        double TavSzorzo() const override;
};

class Feketelyuk : public Objektum {
    public:
        Feketelyuk(std::string a) : Objektum(a) { }

        double TomegSzorzo() const override;
        double TavSzorzo() const override;
};

#endif