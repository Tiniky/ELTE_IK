#ifndef MEGFIGYELES_H
#define MEGFIGYELES_H

#include <string>
#include "Objektum.h"

class Megfigyeles {
    public:
        Objektum* obj;
        std::string datum;
        double tomeg;
        double tav;

    public:
        Megfigyeles(Objektum* o, std::string d, double to, double ta)
            : obj(o), datum(d), tomeg(to), tav(ta) { }

        double Tomeg() const;
        double Tav() const;
};

#endif