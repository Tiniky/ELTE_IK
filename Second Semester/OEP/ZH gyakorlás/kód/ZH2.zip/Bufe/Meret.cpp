#include "Meret.h"

Kicsi* Kicsi::instanceStorage = nullptr;
Kozepes* Kozepes::instanceStorage = nullptr;
Nagy* Nagy::instanceStorage = nullptr;