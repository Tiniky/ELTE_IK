#ifndef KFT_H
#define KFT_H

#include <vector>
#include <string>

#include "Bufe.h"
#include "Vendeg.h"

class Kft {
    private:
        std::vector<Bufe*> uzletek;
        std::vector<Vendeg*> vendegek;

    public:
        Kft() = default;
        ~Kft();

        void UzletetNyit(Bufe*);
        void KartyatAd(Vendeg*);
        bool MindenholVolt();

        std::vector<Bufe*> get_uzletek() { return this->uzletek; }
        std::vector<Vendeg*> get_vendegek() { return this->vendegek; }
};

#endif