#include "Etel.h"
#include "Vendeg.h"

Etel* Etel::Create(std::string etel, int suly, bool menu, std::string meret, Vendeg* v) {
    Etel* e = nullptr;
    
    if(etel == "csirke") {
        e = new Csirke();
    } else if(etel == "rantott") {
        e = new Rantott();
    } else {
        e = new Hekk();
    }

    e->suly = suly;
    e->vendeg = v;

    if(menu) {
        e->menu = new Menu();

        if(meret == "kicsi") {
            e->menu->meret = Kicsi::instance();
        } else if(meret == "kozepes") {
            e->menu->meret = Kozepes::instance();
        } else {
            e->menu->meret = Nagy::instance();
        }
    }

    return e;
}

int Etel::Ar() {
    if(menu != nullptr) {
        return suly * ear + menu->meret->get_ar();
    } else {
        return suly * ear;
    }
}