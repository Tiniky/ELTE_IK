#ifndef VENDEG_H
#define VENDEG_H

#include <string>
#include <vector>

#include "Etel.h"

class Kft;
class Bufe;

class Vendeg {
    private:
        std::string kartya;
        std::vector<Etel*> etelek;

    public:
        Kft* kft;

        Vendeg() = default;
        ~Vendeg();

        void Vasarol(Bufe* b, std::string etel, int suly, bool l, std::string m);
        void Kartya(std::string k);
};

#endif