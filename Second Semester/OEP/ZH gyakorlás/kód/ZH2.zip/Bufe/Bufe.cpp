#include "Bufe.h"
#include "Vendeg.h"
#include "Kft.h"

void Bufe::Elad(Etel* e) {
    forgalom.push_back(e);
}

int Bufe::Mennyit(Vendeg* v) {
    int s = 0;

    for(Etel* e : forgalom) {
        if(e->get_vendeg() == v) {
            s += e->Ar();
        }
    }

    return s;
}

int Bufe::Hany() {
    int s = 0;

    for(Vendeg* e : kft->get_vendegek()) {
        if(Mennyit(e) > 10000) {
            s++;
        }
    }

    return s;
}
