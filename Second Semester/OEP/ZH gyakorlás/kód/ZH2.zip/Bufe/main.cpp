#include <iostream>
#include <fstream>
#include <string>

#include "Kft.h"
#include "Bufe.h"

int main() {
    std::ifstream is("./input.txt");
    if(!is.good()) {
        return 1;
    }

    int bufekSzama = 0;
    is >> bufekSzama;

    Kft* kft = new Kft();

    for(int i = 0; i < bufekSzama; i++) {
        std::string azon;
        std::string cim;

        is >> azon;
        std::getline(is, cim);

        Bufe* bufe = new Bufe(azon, cim);
        kft->UzletetNyit(bufe);
    }

    Bufe* utolsoBufe = nullptr;
    std::string utolsoSzam;
    Vendeg* utolsoVendeg = nullptr;

    while(!is.eof()) {
        std::string kartya;
        std::string bazon;
        std::string etel;
        int suly;
        int menu;
        std::string meret;

        is >> kartya >> bazon >> etel >> suly >> menu;
        if(menu == 1) {
            is >> meret;
        }

        if(utolsoSzam != kartya) {
            utolsoVendeg = new Vendeg();
            utolsoVendeg->Kartya(kartya);
            utolsoSzam = kartya;
        }

        Bufe* b = nullptr;
        for(auto* e : kft->get_uzletek()) {
            if(e->get_azon() == bazon) {
                b = e;
                break;
            }
        }

        utolsoVendeg->Vasarol(b, etel, suly, menu == 1, meret);

        utolsoBufe = b;
    }

    bool igaze = kft->MindenholVolt();
    int koltott = utolsoBufe->Mennyit(utolsoVendeg);
    int mennyien = utolsoBufe->Hany();

    std::cout << (igaze ? "igaz " : "nem ") << koltott << " " << mennyien << std::endl;

    delete kft;

    Nagy::destroy();
    Kicsi::destroy();
    Kozepes::destroy();
    return 0;
}