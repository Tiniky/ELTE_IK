#include "Vendeg.h"
#include "Bufe.h"
#include "Kft.h"

Vendeg::~Vendeg() {
    for(auto* ptr : etelek) {
        delete ptr;
    }

    etelek.clear();
}

void Vendeg::Vasarol(Bufe* b, std::string etel, int suly, bool l, std::string m) {
    bool volt = false;

    for(Vendeg* e : b->kft->get_vendegek()) {
        if(e == this) {
            volt = true;
        }
    }

    if(!volt) {
        b->kft->KartyatAd(this);
    }

    Etel* e = Etel::Create(etel, suly, l, m, this);
    etelek.push_back(e);
    b->Elad(e);
}

void Vendeg::Kartya(std::string k) {
    if(kartya == "") {
        kartya = k;
    }
}