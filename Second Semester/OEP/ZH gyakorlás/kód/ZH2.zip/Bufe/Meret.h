#ifndef MERET_H
#define MERET_H

class Meret {
    public:
        int get_ar() { return this->ar; }

    private:
        int ar;

    protected:
        Meret(int ar) : ar(ar) { }
};

class Kicsi : public Meret {
    public:
        static Kicsi* instance() {
            if(instanceStorage == nullptr) {
                instanceStorage = new Kicsi;
            }

            return instanceStorage;
        }

        static void destroy() {
            if(instanceStorage != nullptr) {
                delete instanceStorage;
                instanceStorage = nullptr;
            }
        }

    private:
        static Kicsi* instanceStorage;

        Kicsi() : Meret(550) { }
};

class Kozepes : public Meret {
    public:
        static Kozepes* instance() {
            if(instanceStorage == nullptr) {
                instanceStorage = new Kozepes;
            }

            return instanceStorage;
        }

        static void destroy() {
            if(instanceStorage != nullptr) {
                delete instanceStorage;
                instanceStorage = nullptr;
            }
        }

    private:
        static Kozepes* instanceStorage;

        Kozepes() : Meret(700) { }
};

class Nagy : public Meret {
    public:
        static Nagy* instance() {
            if(instanceStorage == nullptr) {
                instanceStorage = new Nagy;
            }

            return instanceStorage;
        }

        static void destroy() {
            if(instanceStorage != nullptr) {
                delete instanceStorage;
                instanceStorage = nullptr;
            }
        }

    private:
        static Nagy* instanceStorage;

        Nagy() : Meret(900) { }
};

#endif