#ifndef ETEL_H
#define ETEL_H

#include <string>

#include "Menu.h"

class Vendeg;

class Etel {
    private:
        int ear;
        int suly;

        Menu* menu = nullptr;
        Vendeg* vendeg;

    protected:
        Etel(int ear) : ear(ear) { }

    public:
        int get_ear() { return this->ear; }
        int get_suly() { return this->suly; }
        Vendeg* get_vendeg() { return this->vendeg; }

        static Etel* Create(std::string etel, int suly, bool menu, std::string meret, Vendeg* v);
        int Ar();

        ~Etel() { 
            if(menu != nullptr) {
                delete menu; 
            }
        }
};

class Csirke : public Etel {
    public:
        Csirke() : Etel(250) { }
};

class Rantott : public Etel {
    public:
        Rantott() : Etel(300) { }
};

class Hekk : public Etel {
    public:
        Hekk() : Etel(400) { }
};

#endif