#ifndef BUFE_H
#define BUFE_H

#include <string>
#include <vector>

#include "Etel.h"

class Kft;
class Vendeg;

class Bufe {
    private:
        std::string azon;
        std::string cim;

        std::vector<Etel*> forgalom;

    public:
        Kft* kft;

        Bufe(std::string a, std::string c) : azon(a), cim(c) { }

        void Elad(Etel* e);
        int Mennyit(Vendeg* v);
        int Hany();

        ~Bufe() = default;

        std::string get_azon() { return this->azon; }
        std::string get_cim() { return this->cim; }
};

#endif