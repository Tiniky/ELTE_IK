#include "Kft.h"
#include "Bufe.h"
#include "Vendeg.h"

Kft::~Kft() {
    for (auto *ptr : uzletek) {
        delete ptr;
    }

    for (auto *ptr : vendegek) {
        delete ptr;
    }

    uzletek.clear();
    vendegek.clear();
}

void Kft::UzletetNyit(Bufe* bufe) {
    bool volt = false;

    for(Bufe* e : uzletek) {
        if(e->get_azon() == bufe->get_azon() || e->get_cim() == bufe->get_cim()) {
            volt = true;
        }
    }

    if(!volt) {
        bufe->kft = this;
        uzletek.push_back(bufe);
    } else {
        // TODO: Error
    }
}

void Kft::KartyatAd(Vendeg* v) {
    bool volt = false;

    for(Vendeg* e : vendegek) {
        if(e == v) {
            volt = true;
        }
    }

    if(!volt) {
        v->kft = this;
        v->Kartya("aaa");
        vendegek.push_back(v);
    }
}

bool Kft::MindenholVolt() {
    bool b = true;

    for(Bufe* e : uzletek) {
        b = b && e->Hany() > 0;
    }

    return b;
}