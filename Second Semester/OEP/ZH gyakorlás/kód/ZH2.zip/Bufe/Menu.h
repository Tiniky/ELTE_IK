#ifndef MENU_H
#define MENU_H

#include "Meret.h"

class Menu {
    public:
        Meret* meret;
};

#endif