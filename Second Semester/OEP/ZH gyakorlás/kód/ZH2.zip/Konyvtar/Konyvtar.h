#ifndef KONYVTAR_H
#define KONYVTAR_H

#include "Kolcson.h"
#include "Konyv.h"
#include "Szemely.h"

#include <vector>
#include <string>
#include <tuple>

class Konyvtar {
    private:
        static int id;

        std::vector<Szemely*> tagok;
        std::vector<Kolcson*> kolcs;
        std::vector<Konyv*> konyvek;

        bool Tag(Szemely*);
        std::tuple<bool, Konyv*> Keres(int az);

        int general() { return id++; }

    public:
        Konyvtar() = default;
        ~Konyvtar() {
            for(auto* ptr : tagok) {
                delete ptr;
            }

            for(auto* ptr : kolcs) {
                delete ptr;
            }

            for(auto* ptr : konyvek) {
                delete ptr;
            }
        }

        void Bevetelez(Konyv*);
        void Belep(Szemely*);
        void Visszahoz(std::vector<int> lista);
        void Kolcsonoz(Szemely*, std::vector<int> lista, int ma);
        int Potdij(Szemely*, int ma);

        std::vector<Szemely*> get_tagok() { return tagok; }
        std::vector<Kolcson*> get_kolcs() { return kolcs; }
        std::vector<Konyv*> get_konyvek() { return konyvek; }
};

#endif