#include "Szemely.h"
#include "Konyvtar.h"

void Szemely::Rogzit(Kolcson* k) {
    kolcs.push_back(k);
}

Konyvtar* Szemely::get_konyvtar() {
    return konyvtar;
}

void Szemely::set_konyvtar(Konyvtar* k) {
    konyvtar = k;
}