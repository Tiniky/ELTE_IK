#ifndef KONYV_H
#define KONYV_H

#include <string>

#include "Mufaj.h"

class Kolcson;

class Konyv {
    private:
        std::string cim;
        std::string szerzo;
        int oldal;
        Mufaj* mufaj;

        Kolcson* fej;

    public:
        int azon;
        bool kinn;

        Konyv(std::string cim, std::string szerzo, int oldal, Mufaj* mufaj) 
            : azon(0), cim(cim), szerzo(szerzo), oldal(oldal), kinn(false), mufaj(mufaj) { }

        int Dij(int ma);

        std::string get_cim() { return cim; }
        std::string get_szerzo() { return szerzo; }
        int get_oldal() { return oldal; }
        void set_fej(Kolcson* fej) { this->fej = fej; }
        int get_azon() { return azon; }
        bool get_kinn() { return kinn; }
        Mufaj* get_mufaj() { return mufaj; }
        Kolcson* get_fej() { return fej; }

        friend std::istream& operator>>(std::istream&, Konyv*&);
};

#endif