#include "Kolcson.h"
#include "Konyvtar.h"
#include "Szemely.h"

int Kolcson::Potdij(int ma) {
    int s = 0;

    for(Konyv* e : tetelek) {
        if(e->kinn) {
            s += e->Dij(ma);
        }
    }

    return s;
}

Konyvtar* Kolcson::get_konyvtar() { return konyvtar; }
Szemely* Kolcson::get_tag() { return tag; }