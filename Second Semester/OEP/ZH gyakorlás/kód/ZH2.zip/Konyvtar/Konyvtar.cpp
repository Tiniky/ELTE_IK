#include "Konyvtar.h"

#include <algorithm>

bool Konyvtar::Tag(Szemely* sz) {
    bool volt = false;
    for(Szemely* e : tagok) {
        if(e->get_nev() == sz->get_nev()) {
            volt = true;
        }
    }
    return volt;
}

std::tuple<bool, Konyv*> Konyvtar::Keres(int az) {
    Konyv* elem = nullptr;
    bool l = false;
    for(Konyv* e : konyvek) {
        if(e->azon == az) {
            elem = e;
            l = true;
        }
    }
    return { l, elem };
}

int Konyvtar::id = 1;

void Konyvtar::Bevetelez(Konyv* k) {
    k->azon = general();
    konyvek.push_back(k);
}

void Konyvtar::Belep(Szemely* sz) {
    if(!Tag(sz)) {
        tagok.push_back(sz);
        sz->set_konyvtar(this);
    }
}

void Konyvtar::Visszahoz(std::vector<int> lista) {
    for(int az : lista) {
        std::tuple<bool, Konyv*> lk = Keres(az);
        bool l = std::get<0>(lk);
        Konyv* k = std::get<1>(lk);

        if(l && k->get_kinn()) {
            std::vector<Konyv*>* tetelek = &(k->get_fej()->tetelek);
            tetelek->erase(std::remove(tetelek->begin(), tetelek->end(), k), tetelek->end());
            k->kinn = false;
        }
    }
}

void Konyvtar::Kolcsonoz(Szemely* sz, std::vector<int> lista, int ma) {
    if(!Tag(sz) && lista.size() > 5) {
        return;
    }

    Kolcson* kg = new Kolcson(this, sz, ma);

    for(int az : lista) {
        std::tuple<bool, Konyv*> lk = Keres(az);
        bool l = std::get<0>(lk);
        Konyv* k = std::get<1>(lk);

        if(l && !k->kinn) {
            kg->tetelek.push_back(k);
            k->kinn = true;
            k->set_fej(kg);
        }
    }

    kolcs.push_back(kg);
    sz->Rogzit(kg);
}

int Konyvtar::Potdij(Szemely* sz, int ma) {
    int s = 0;
    for(Kolcson* e : kolcs) {
        if(e->get_tag() == sz) {
            s += e->Potdij(ma);
        }
    }
    return s;
}