#ifndef SZEMELY_H
#define SZEMELY_H

#include <string>
#include <vector>

#include "Kolcson.h"

class Konyvtar;

class Szemely {
    private:
        std::string nev;
        Konyvtar* konyvtar;
        std::vector<Kolcson*> kolcs;

    public:
        Szemely(std::string nev) : nev(nev) { }

        void Rogzit(Kolcson* k);

        void set_konyvtar(Konyvtar*);
        std::string get_nev() { return nev; }
        Konyvtar* get_konyvtar();
        std::vector<Kolcson*> get_kolcs() { return kolcs; }
};

#endif