#ifndef KOLCSON_H
#define KOLCSON_H

#include "Konyv.h"

#include <vector>

class Szemely;
class Konyvtar;

class Kolcson {
    private:
        int datum;
        Konyvtar* konyvtar;
        Szemely* tag;

    public:
        std::vector<Konyv*> tetelek;

        Kolcson(Konyvtar* k, Szemely* sz, int d)
            : datum(d), konyvtar(k), tag(sz) { }

        int Potdij(int ma);

        int get_datum() { return datum; }
        Konyvtar* get_konyvtar();
        Szemely* get_tag();
        std::vector<Konyv*> get_tetelek() { return tetelek; }
};

#endif