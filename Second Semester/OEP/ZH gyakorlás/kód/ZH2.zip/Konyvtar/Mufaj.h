#ifndef MUFAJ_H
#define MUFAJ_H

class Mufaj {
    public:
        virtual int Dij() = 0;
};

class Termeszettudomanyos : public Mufaj {
    private:
        Termeszettudomanyos() = default;
        static Termeszettudomanyos* storage;

    public:
        int Dij() override { return 100; }

        static Termeszettudomanyos* instance() {
            if(storage == nullptr) {
                storage = new Termeszettudomanyos;
            }

            return storage;
        }

        static void destroy() {
            if(storage != nullptr) {
                delete storage;
            }

            storage = nullptr;
        }
};

class Szepirodalmi : public Mufaj {
    private:
        Szepirodalmi() = default;
        static Szepirodalmi* storage;

    public:
        int Dij() override { return 50; }

        static Szepirodalmi* instance() {
            if(storage == nullptr) {
                storage = new Szepirodalmi;
            }

            return storage;
        }

        static void destroy() {
            if(storage != nullptr) {
                delete storage;
            }

            storage = nullptr;
        }
};

class Ifjusagi : public Mufaj {
    private:
        Ifjusagi() = default;
        static Ifjusagi* storage;

    public:
        int Dij() override { return 20; }

        static Ifjusagi* instance() {
            if(storage == nullptr) {
                storage = new Ifjusagi;
            }

            return storage;
        }

        static void destroy() {
            if(storage != nullptr) {
                delete storage;
            }

            storage = nullptr;
        }
};

#endif