//ide tedd az a header fájlok includejait
#include "Konyv.h"
#include "Szemely.h"
#include "Konyvtar.h"

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

int main() {
    Konyvtar* konyvtar = new Konyvtar();

    std::ifstream is("input.txt");
    if(!is.good()) {
        return 1;
    }

    int maiDatum;
    is >> maiDatum;

    int konyvekSzama;
    is >> konyvekSzama;

    for(int i = 0; i < konyvekSzama; i++) {
        Konyv* konyv;
        is >> konyv;
        
        konyvtar->Bevetelez(konyv);
    }

    int tagokSzama;
    is >> tagokSzama;

    for(int i = 0; i < tagokSzama; i++) {
        std::string nev;
        int tranzakciok;

        is >> nev >> tranzakciok;

        Szemely* szemely = new Szemely(nev);
        konyvtar->Belep(szemely);

        for(int j = 0; j < tranzakciok; j++) {
            std::string irany;
            std::string sor;

            is >> irany;
            std::getline(is, sor);

            std::stringstream ss(sor);

            if(irany == "ki") {
                int datum;
                ss >> datum;

                std::vector<int> lista;

                int n;
                while(ss >> n) {
                    lista.push_back(n);
                }

                konyvtar->Kolcsonoz(szemely, lista, datum);
            } else if(irany == "vissza") {
                std::vector<int> lista;

                int n;
                while(ss >> n) {
                    lista.push_back(n);
                }

                konyvtar->Visszahoz(lista);
            }
        }

        std::cout << szemely->get_nev() << " " << konyvtar->Potdij(szemely, maiDatum) << std::endl;
    }

    Termeszettudomanyos::destroy();
    Szepirodalmi::destroy();
    Ifjusagi::destroy();

    delete konyvtar;
}