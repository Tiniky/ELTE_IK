#include "Konyv.h"
#include "Kolcson.h"

int Konyv::Dij(int ma) {
    int keses = ma - (fej->get_datum() + 30);

    if(keses > 0) {
        return keses * mufaj->Dij();
    } else {
        return 0;
    }
}

#include <iostream>

std::istream& operator>>(std::istream& is, Konyv*& k) {
    std::string cim;
    std::string szerzo;
    int oldal;
    char mufaj;

    is >> cim >> szerzo >> oldal >> std::ws >> mufaj;

    Mufaj* mufajPtr = nullptr;
    switch(mufaj) {
        case 't':
            mufajPtr = Termeszettudomanyos::instance();
            break;

        case 's':
            mufajPtr = Szepirodalmi::instance();
            break;

        case 'i':
            mufajPtr = Ifjusagi::instance();
            break;
    }

    k = new Konyv(cim, szerzo, oldal, mufajPtr);
    return is;
}