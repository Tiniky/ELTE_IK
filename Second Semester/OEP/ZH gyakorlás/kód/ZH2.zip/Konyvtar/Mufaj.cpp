#include "Mufaj.h"

Termeszettudomanyos* Termeszettudomanyos::storage = nullptr;
Szepirodalmi* Szepirodalmi::storage = nullptr;
Ifjusagi* Ifjusagi::storage = nullptr;