#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "Plant.hpp"
#include "Radiant.hpp"
using namespace std;

int createPlant(const std::string fileName, std::vector<Plant*> &plants){
    ifstream f(fileName);
    if(f.fail()){
        std::cout << "Sowwy but I can't find the file o.o" << std::endl;
        exit(1);
    }

    int plantDB, dayDB, nut;
    std::string name, line;
    char type;

    f >> plantDB;
    plants.clear();
    plants.resize(plantDB);

    int i = 0;
    while(getline(f, line)){
        std::istringstream data(line);

        if(i == plantDB){
            data >> dayDB;
        } else {
            data >> name >> type >> nut;
            plants.push_back(Plant::create(name, type, nut));
            i++;
        }
    }

    return dayDB;
}

int main()
{
    Radiant* rad = Radiant::create();

    std::vector<Plant*> plants;
    int days = createPlant("input.txt", plants);

    std::cout << days << std::endl;

    for(Plant* p:plants){
        std::cout << p->getName() << std::endl;
    }

}
