#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "Plant.hpp"
#include "Radiant.hpp"
using namespace std;

void createPlanet(const std::string &fileName, vector<Plant*> &plants, int* &days){
    std::ifstream f(fileName);
    if(f.fail()){
        std::cout << "File name error!" << std::endl;
        exit(1);
    }

    int plantDB, dayDB, nut;
    std::string line, name;
    char type;

    f >> plantDB;
    plants.resize(plantDB);
    int i = 0;

    while(getline(f, line)){
        std::istringstream data(line);
        f >> name >> type >> nut;
        plants.push_back(Plant::create(name, type, nut));
        i++;

        if(i == plantDB){
            f >> dayDB;
        }
    }

    days = &dayDB;
}

void daysLater(vector<Plant*> &plants, Radiant* &rad, int* &dayDB, std::string &strongestSurvivor, vector<std::string>& report){
    try{
        while(dayDB > 0){
            int need = 0;



            if(need >= 3){
                rad->~Radiant();
                rad = Alpha::Instance();
                report.push_back("ALPHA RADIATION");
            } else if(need <= -3){
                rad->~Radiant();
                rad = Delta::Instance();
                report.push_back("DELTA RADIATION");
            } else {
                rad->~Radiant();
                rad = NoRad::Instance();
                report.push_back("NO RADIATION");
            }

            for(Plant* p : plants){
                std::string plant = "";
                stringstream ss;

                need = p->transMute(need, rad);

                plant = plant + p->getName() + " ";
                ss << p->getNut();

                if(p->isPuffancs()){
                    plant = plant + "puffancs " + ss.str();
                } else if(p->isDeltafa()){
                    plant = plant + "deltafa " + ss.str();
                } else if(p->isParabokor()){
                    plant = plant + "parabokor " + ss.str();
                }

                report.push_back(plant);
            }

            dayDB--;
        }

        int nutMax = 0;
        std::string strongest;

        for(Plant* p : plants){
            if(p->isAlive() && p->getNut()>nutMax){
                strongest = p->getName();
            }
        }

        if(nutMax == 0){
            strongestSurvivor = "There are no survivors.. wthigo";
        } else{
            strongestSurvivor = "The strongest survivor is " + strongest;
        }
    } catch(exception e){
        std::cout << e.what() << std::endl;
    }
}

void destroyAll(vector<Plant*> &plants){
    for(Plant* p : plants){
        delete p;
    }

    Alpha::destroy();
    Delta::destroy();
    NoRad::destroy();
}

#define NORMAL_MODE
//#ifdef NORMAL_MODE

int main()
{
    vector<Plant*> plants;
    Radiant* rad = Radiant::create();
    int* days = 0;
    createPlanet("input.txt", plants, days);

    for(Plant* p: plants){
        std::cout << p->getName() << std::endl;
    }
    std :: cout << *days << std::endl;

    std::string ss;
    vector<std::string> report;
    daysLater(plants, rad, days, ss, report);

    for(std::string s : report){
        std::cout << s << std::endl;
    }
    std::cout << ss << std::endl;

    destroyAll(plants);

    return 0;
}
